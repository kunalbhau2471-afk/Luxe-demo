package com.example.luxe;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int gold = Color.rgb(214,180,106), cream = Color.rgb(245,241,231);
    String[] names = {"iPhone 17 Pro Max", "MacBook Pro", "Rolex Submariner", "Designer Sneakers"};
    String[] prices = {"₹1,64,900", "₹2,49,900", "₹12,50,000", "₹89,000"};
    String[] emojis = {"📱","💻","⌚","👟"};
    int cart = 0;
    LinearLayout root, list;
    TextView cartText;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(16,16,16));
        getWindow().setNavigationBarColor(Color.rgb(16,16,16));
        showHome();
    }
    GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    void pad(View v, int l,int t,int r,int b){v.setPadding(l,t,r,b);}
    void setup(String title) {
        root = new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(Color.rgb(16,16,16));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this); content.setOrientation(1); pad(content,20,18,20,28);
        TextView brand = text("L U X E", 27, gold, true); brand.setGravity(Gravity.CENTER);
        content.addView(brand);
        TextView demo = text("DEMO EXPERIENCE  •  NOT A REAL STORE OR ORDER", 10, Color.BLACK, true);
        demo.setGravity(Gravity.CENTER); demo.setBackground(bg(gold,18)); pad(demo,10,9,10,9);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1,-2); dp.setMargins(0,14,0,22); content.addView(demo,dp);
        TextView heading = text(title,23,cream,true); content.addView(heading);
        scroll.addView(content); root.addView(scroll); setContentView(root); list=content;
    }
    void showHome() {
        setup("Discover the extraordinary");
        TextView sub=text("Curated luxury picks for your demo collection.",14,0xFFBDB8AE,false);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2); sp.setMargins(0,8,0,18); list.addView(sub,sp);
        cartText=text("🛍  Demo cart: "+cart,14,gold,true); list.addView(cartText);
        for(int i=0;i<names.length;i++){
            final int n=i;
            LinearLayout card=new LinearLayout(this); card.setOrientation(1); card.setBackground(bg(0xFF242321,18)); pad(card,16,15,16,15);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,13,0,0); list.addView(card,cp);
            TextView icon=text(emojis[i],34,cream,false); card.addView(icon);
            TextView name=text(names[i],18,cream,true); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2); np.setMargins(0,8,0,3); card.addView(name,np);
            card.addView(text(prices[i],16,gold,true));
            Button add=new Button(this); add.setText("ADD TO DEMO CART"); add.setTextColor(Color.BLACK); add.setBackground(bg(gold,14));
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.setMargins(0,12,0,0); card.addView(add,bp);
            add.setOnClickListener(v->{cart++; showHome();});
        }
        Button checkout=new Button(this); checkout.setText("VIEW DEMO CART  ("+cart+")"); checkout.setTextColor(Color.BLACK); checkout.setBackground(bg(gold,14));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.setMargins(0,20,0,0); list.addView(checkout,bp);
        checkout.setOnClickListener(v->showCart());
    }
    void showCart() {
        setup("Your demo cart");
        list.addView(text("Items added: "+cart,18,cream,true));
        list.addView(text("This screen is a simulation. No payment details are collected and no purchase is made.",14,0xFFBDB8AE,false));
        Button place=new Button(this); place.setText("SIMULATE ORDER"); place.setTextColor(Color.BLACK); place.setBackground(bg(gold,14));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,22,0,8); list.addView(place,p);
        place.setOnClickListener(v->showSuccess());
        Button back=new Button(this); back.setText("BACK TO STORE"); list.addView(back); back.setOnClickListener(v->showHome());
    }
    void showSuccess() {
        setup("Demo order complete ✨");
        TextView mark=text("✓",64,gold,true); mark.setGravity(Gravity.CENTER); list.addView(mark);
        TextView msg=text("SIMULATED SUCCESS",22,cream,true); msg.setGravity(Gravity.CENTER); list.addView(msg);
        TextView note=text("This is a fictional demo order only. No money was charged, no merchant was contacted, and no product was ordered.",15,0xFFBDB8AE,false);
        note.setGravity(Gravity.CENTER); pad(note,12,18,12,18); list.addView(note);
        Button home=new Button(this); home.setText("RETURN TO LUXE"); list.addView(home); home.setOnClickListener(v->{cart=0;showHome();});
    }
}
