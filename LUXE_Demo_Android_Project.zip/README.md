# LUXE Demo Android project

This is a clearly labeled fictional shopping demo. It does not connect to Flipkart, Amazon, payment processors, merchants, or delivery services. It does not collect card details or create real orders.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `LUXE_Demo_Android` folder in Android Studio.
3. Allow Gradle sync to complete (internet is needed the first time to download Android Gradle Plugin).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location.

The current environment does not have the Android SDK/Gradle build tools, so this archive contains the Android Studio project source rather than a compiled APK.
